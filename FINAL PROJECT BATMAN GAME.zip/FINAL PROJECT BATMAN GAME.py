from tkinter import *
import tkinter.simpledialog
import tkinter.messagebox
from tkinter import ttk
from time import strftime
from COLORGAME import COLORGAME
now = strftime("OH NO, the Riddler captured my son!! Batman can you please catch him and retrieve my son?")


root=Tk()
root.title("BATMAN VS THE RIDDLER")
canvas= Canvas(root, width=350, height=250)
canvas.pack()
photo=PhotoImage(file='riddler.gif')
canvas.create_image(0, 0, anchor = NW, image=photo)




tkinter.messagebox.showinfo("RIDDLES", now)

name=tkinter.simpledialog.askstring("??", "DO YOU HAVE WHAT IT TAKES TO TRACK DOWN THE RIDDLER" )

output = " %s Thank you so much. When the riddler took my son he gave me this note to give to you (close the picture to view note)" %name

tkinter.messagebox.showinfo(now, output)

def on_closing():
    
    if tkinter.messagebox.askokcancel("Quit", "Do you want to quit?"):
        root.destroy()

root.protocol(on_closing)
root.mainloop()











from tkinter import *
from tkinter import messagebox
import time


root = Tk()
root.title("Main")
root.geometry("900x500")
global e1
global e2


Label(root, text = "Dear Batman, \n \n I see you have heard the womans crys. Well they are very true I have her son. \n You know I like to play games, I mean riddles, \n so here is what we are gonna do. \n You complete my riddles... and ill set the boy free. \n sounds like a good deal right? \  Riddle: What time is it when an elephant sits on a fence? Answer: Time to fix the fence!").place(x=5, y=5)
root.mainloop()
time.sleep(1)
root.quit()

# START = input("Enter start to begin")
# 
# if(START == "start"):
#     root.destroy()
    




